import QRCode from "qrcode";

import { getCompanySettings } from "@/lib/company-settings";
import { sendEmail } from "@/lib/email-service";
import type { EventItem, EventGuest } from "@/lib/event-platform-store";

export async function sendCheckinEmail(
  event: EventItem,
  guest: EventGuest
): Promise<void> {
  if (!guest.checkinToken) return;

  const settings = await getCompanySettings();

  // Gera o QR Code como Data URL (base64), sem precisar de anexo separado
  const qrDataUrl = await QRCode.toDataURL(guest.checkinToken, {
    width: 300,
    margin: 2,
  });

  const dataLabel = guest.selectedDate
    ? `<p><strong>Data:</strong> ${guest.selectedDate}</p>`
    : event.startInfo
    ? `<p><strong>Data:</strong> ${event.startInfo}</p>`
    : "";

  const html = `
    <div style="font-family: Arial, sans-serif; line-height: 1.6; max-width: 520px; margin: 0 auto;">
      <h2 style="color: ${event.primaryColor};">Inscrição confirmada! 🎉</h2>
      <p>Olá, <strong>${guest.name}</strong>!</p>
      <p>Sua participação em <strong>${event.name}</strong> foi confirmada com sucesso.</p>
      <p><strong>Local:</strong> ${event.location || "A definir"}</p>
      ${dataLabel}
      <p><strong>Participantes:</strong> ${guest.participants ?? 1}</p>
      <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;" />
      <p>Apresente o QR Code abaixo na entrada do evento para realizar seu check-in:</p>
      <div style="text-align: center; margin: 20px 0;">
        <img src="${qrDataUrl}" alt="QR Code de check-in" width="240" height="240" />
      </div>
      <p style="font-size: 12px; color: #888; text-align: center;">
        Código de check-in: ${guest.checkinToken}
      </p>
    </div>
  `;

  const text = `Olá, ${guest.name}! Sua participação em ${event.name} foi confirmada. Local: ${
    event.location || "A definir"
  }. Apresente o código ${guest.checkinToken} na entrada do evento.`;

  await sendEmail(settings, {
    to: guest.email,
    subject: `Confirmação de presença: ${event.name}`,
    html,
    text,
  });
}
